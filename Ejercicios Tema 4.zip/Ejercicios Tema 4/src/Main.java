import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        int numeroIf = 0;
        if (numeroIf < 0) {
            System.out.println("es negativo");
        } else if (numeroIf > 0) {
            System.out.println("es positivo");
        } else {
            System.out.println("la variable numeroIf es 0");
        }

        int numeroWhile = 0;

        while (numeroWhile < 3) {
            System.out.println(numeroWhile);
            numeroWhile = numeroWhile + 1;

            do {
                System.out.println(numeroWhile);
                numeroWhile = numeroWhile + 1;
            } while (numeroWhile < 3);

        }
        for (int numeroFor = 0; numeroFor <= 3; numeroFor = numeroFor + 1) {
            System.out.println(numeroFor);
        }



    {
        var estacion = "OTOÑO";

        switch (estacion) {
            case "VERANO":
                System.out.println("ES VERANO");
                break;
            case "OTOÑO":
                System.out.println("ES OTOÑO");
                break;
            case "INVIERNO":
                System.out.println("ES INVIERNO");
                break;
            case "PRIMAVERA":
                System.out.println("ES PRIMAVERA");


            default:
                System.out.println("Estoy en default");
        }}}}
































